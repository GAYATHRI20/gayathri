package guvi;
import java.io.*;
import java.util.Scanner;
public class Add {
public static void main(String[] args)
{


			int a=Integer.parseInt(args[0]);
	if(a%2==0)
	{
		System.out.println("even number");
	}
		else
		{
			System.out.println("odd number");
		  
	}
}
}
