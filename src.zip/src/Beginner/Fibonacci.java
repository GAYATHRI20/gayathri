package Beginner;

public class Fibonacci {

	public static void main(String[] args) {
       int i=0,j=1;
       System.out.println(i+" "+j);
       for()
	}

}
